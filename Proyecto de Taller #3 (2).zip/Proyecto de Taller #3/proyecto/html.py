import webview
from pr import App as App

def generate_html(self):
    # Generar contenido HTML basado en los datos de la agenda
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>{self.agenda.titulo}</title>
        <style>
            /* Estilos CSS personalizados */
            /* ... */
        </style>
    </head>
    <body>
        <h1>{self.agenda.titulo}</h1>
        <p>Fecha de creación: {self.agenda.fecha_creacion}</p>
        
        <h2>Participantes:</h2>
        <ul>
            {"".join(f"<li>{participant}</li>" for participant in self.participants)}
        </ul>
        
        <h2>Apartados:</h2>
        <ul>
            {"".join(f"<li>{section.apartado}<ol>{''.join(f'<li>{point.punto}</li>' for point in self.points)}</ol></li>" for section in self.sections)}
        </ul>
    </body>
    </html>
    """
    return html

def open_new_window(self):
    # Generar el contenido HTML
    html = self.generate_html()

    # Crear una nueva ventana de WebView y mostrar el contenido HTML
    webview.create_window("Agenda HTML", html=html)

