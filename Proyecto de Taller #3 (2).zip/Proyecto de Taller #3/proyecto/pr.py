import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import datetime
from agenda import lista, persona, discusion, puntos, apartados, agenda

class App(agenda):
    def __init__(self, root):
        super().__init__()
        # Crear la ventana principal
        self.root = root
        self.root.geometry("450x650")

        self.agenda = agenda()

        self.participants = []
        self.sections = []
        self.points = []
        self.agendas = []
        # Definición de los widgets de entrada y botones
        self.agenda_title_label = tk.Label(root, text="Título de la Agenda")
        self.agenda_title_entry = tk.Entry(root)
        self.agenda_title_button = tk.Button(root, text="Añadir Título de la Agenda", command=self.set_agenda_title)

        self.participant_name_label = tk.Label(root, text="Nombre del Participante")
        self.participant_name_entry = tk.Entry(root)
        self.participant_surname1_label = tk.Label(root, text="Primer Apellido del Participante")
        self.participant_surname1_entry = tk.Entry(root)
        self.participant_surname2_label = tk.Label(root, text="Segundo Apellido del Participante")
        self.participant_surname2_entry = tk.Entry(root)
        self.participant_button = tk.Button(root, text="Añadir Participante", command=self.add_participant)

        self.section_name_label = tk.Label(root, text="Nombre del Apartado")
        self.section_name_entry = tk.Entry(root)
        self.section_button = tk.Button(root, text="Añadir Apartado", command=self.add_section)

        self.point_name_label = tk.Label(root, text="Nombre del Punto")
        self.point_name_entry = tk.Entry(root)
        self.point_section_name_label = tk.Label(root, text="Apartado Asociado al Punto")
        self.point_section_name_combobox = ttk.Combobox(root)
        self.point_button = tk.Button(root, text="Añadir Punto", command=self.add_point)

        self.discussion_name_label = tk.Label(root, text="Transcripción de la Discusión")
        self.discussion_name_entry = tk.Entry(root)
        self.discussion_participant_name_label = tk.Label(root, text="Nombre del Participante que Discute")
        self.discussion_participant_name_combobox = ttk.Combobox(root)
        self.discussion_point_name_label = tk.Label(root, text="Punto Asociado a la Discusión")
        self.discussion_point_name_combobox = ttk.Combobox(root)
        self.discussion_button = tk.Button(root, text="Añadir Discusión", command=self.add_discussion)

        self.open_window_button = tk.Button(root, text="Mantenimiento", command=self.open_new_window)

        self.discussion_treeview = ttk.Treeview(root, columns=("Discussion", "Participant", "Point"), show="headings", height=5)
        self.discussion_treeview.heading("Discussion", text="Transcripción de la Discusión")
        self.discussion_treeview.heading("Participant", text="Participante")
        self.discussion_treeview.heading("Point", text="Punto")
        self.discussion_treeview.pack()

        open_table_button = tk.Button(root, text="Abrir Tabla", command=self.open_table)
        open_table_button.pack()
        
        toggle_table_button = tk.Button(root, text="Mostrar/Ocultar Tabla", command=self.toggle_table_visibilityy)
        toggle_table_button.pack()

        # Empaquetar los widgets para que se muestren
        self.agenda_title_label.pack()
        self.agenda_title_entry.pack()
        self.agenda_title_button.pack()

        self.participant_name_label.pack()
        self.participant_name_entry.pack()
        self.participant_surname1_label.pack()
        self.participant_surname1_entry.pack()
        self.participant_surname2_label.pack()
        self.participant_surname2_entry.pack()
        self.participant_button.pack()

        self.section_name_label.pack()
        self.section_name_entry.pack()
        self.section_button.pack()

        self.point_name_label.pack()
        self.point_name_entry.pack()
        self.point_section_name_label.pack()
        self.point_section_name_combobox.pack()
        self.point_button.pack()

        self.discussion_name_label.pack()
        self.discussion_name_entry.pack()
        self.discussion_participant_name_label.pack()
        self.discussion_participant_name_combobox.pack()
        self.discussion_point_name_label.pack()
        self.discussion_point_name_combobox.pack()
        self.discussion_button.pack()

        self.open_window_button.pack()

    def toggle_table_visibilityy(self):
        if self.discussion_treeview.winfo_ismapped():
            self.discussion_treeview.pack_forget()  # Oculta la tabla si ya está visible
        else:
            self.discussion_treeview.pack()

    def add_new_discussion(self, discussion_treeview, discussion_text_entry, participant_combobox, point_combobox):
        discussion_text = discussion_text_entry.get()
        discussion_participant_name = participant_combobox.get()
        point_name = point_combobox.get()

        if not discussion_text.strip() or not discussion_participant_name.strip() or not point_name.strip():
            messagebox.showerror("Error", "Debes llenar todos los campos de entrada.")
            return

        discussion_participant = next((p for p in self.participants if " ".join([p.nombre, p.apellido1, p.apellido2]) == discussion_participant_name), None)
        if discussion_participant is None:
            messagebox.showerror("Error", f"No se encontró el participante: {discussion_participant_name}")
            return

        target_point = next((p for p in self.points if p.punto == point_name), None)
        if target_point is None:
            messagebox.showerror("Error", f"No se encontró el punto: {point_name}")
            return

        discussion = discusion(discussion_participant, discussion_text)

        if target_point.discusiones is None:
            target_point.discusiones = discussion
        else:
            last_discussion = target_point.discusiones
            while last_discussion.sig is not None:
                last_discussion = last_discussion.sig
            last_discussion.sig = discussion

        messagebox.showinfo("Éxito", f"Discusión añadida: {discussion_text} por {discussion_participant_name} en el punto {point_name}")

        # Agregar una nueva fila a la tabla con la transcripción de la discusión, el participante y el punto
        self.add_discussion_row(discussion_text, discussion_participant_name, point_name)


        # Limpiar los campos de entrada
        self.discussion_name_entry.delete(0, tk.END)
        self.discussion_participant_name_combobox.delete(0, tk.END)
        self.discussion_point_name_combobox.delete(0, tk.END)

        # Cerrar la ventana de la tabla
        self.table_window.destroy()



    def open_table(self):
        self.table_window = tk.Toplevel(self.root)  # Crear una nueva ventana
        self.table_window.geometry("700x400")  # Establecer el tamaño de la ventana

        discussion_treeview = ttk.Treeview(self.table_window, columns=("Discussion", "Participant", "Point"), show="headings", height=5)
        discussion_treeview.heading("Discussion", text="Transcripción de la Discusión")
        discussion_treeview.heading("Participant", text="Participante")
        discussion_treeview.heading("Point", text="Punto")

        # Agregar los valores a la nueva tabla
        for value in self.discussion_treeview.get_children():
            discussion_treeview.insert("", "end", values=self.discussion_treeview.item(value)['values'])

        discussion_treeview.pack()

        # Crear combobox para seleccionar participantes registrados
        participant_label = tk.Label(self.table_window, text="Seleccionar Participante:")
        participant_label.pack()

        participant_combobox = ttk.Combobox(self.table_window, values=[" ".join([p.nombre, p.apellido1, p.apellido2]) for p in self.participants])
        participant_combobox.pack()

        # Crear combobox para seleccionar puntos registrados
        point_label = tk.Label(self.table_window, text="Seleccionar Punto:")
        point_label.pack()

        point_combobox = ttk.Combobox(self.table_window, values=[p.punto for p in self.points])
        point_combobox.pack()

        discussion_text_label = tk.Label(self.table_window, text="Transcripción de la Discusión:")
        discussion_text_label.pack()

        discussion_text_entry = tk.Entry(self.table_window)
        discussion_text_entry.pack()

        add_button = tk.Button(self.table_window, text="Añadir Discusión", command=lambda: self.add_new_discussion(discussion_treeview, discussion_text_entry, participant_combobox, point_combobox))
        add_button.pack()



    def set_agenda_title(self):
        title = self.agenda_title_entry.get().strip()
        date = datetime.datetime.now().strftime("%Y-%m-%d")  # Obtener la fecha actual

        if not title:
            messagebox.showerror("Error", "El título de la agenda no puede estar en blanco.")
            return

        self.agenda_title_entry.config(state="disabled")  # Deshabilitar la entrada después de establecer el título
        self.agendas.append(f"{title} - {date}")  # Combinar título y fecha
        messagebox.showinfo("Éxito", f"Título de la Agenda establecido: {title}")
        self.agenda_title_entry.delete(0, tk.END)


    def add_participant(self):
        _name = self.participant_name_entry.get().strip()
        _surname1 = self.participant_surname1_entry.get().strip()
        _surname2 = self.participant_surname2_entry.get().strip()

        if not _name or not _surname1 or not _surname2:
            messagebox.showerror("Error", "Los campos del participante no pueden estar en blanco.")
            return

        # Verificar si el participante ya existe
        if any(p.nombre == _name and p.apellido1 == _surname1 and p.apellido2 == _surname2 for p in self.participants):
            messagebox.showerror("Error", f"El participante {_name} {_surname1} {_surname2} ya existe.")
            return

        participant = persona(_name, _surname1, _surname2)
        self.participants.append(participant)
        self.discussion_participant_name_combobox['values'] = [" ".join([p.nombre, p.apellido1, p.apellido2]) for p in self.participants]
        self.participant_name_entry.delete(0, tk.END)
        self.participant_surname1_entry.delete(0, tk.END)
        self.participant_surname2_entry.delete(0, tk.END)

        messagebox.showinfo("Éxito", f"Participante añadido: {_name} {_surname1} {_surname2}")


    def add_section(self):
        _name = self.section_name_entry.get()

        if not _name.strip():
            messagebox.showerror("Error", "El nombre del apartado no puede estar en blanco.")
            return

        if any(s.apartado == _name for s in self.sections):
            messagebox.showerror("Error", f"El apartado {_name} ya existe.")
            return

        section = apartados(_name)
        self.sections.append(section)
        self.point_section_name_combobox['values'] = [s.apartado for s in self.sections]

        messagebox.showinfo("Éxito", f"Apartado añadido: {_name}")

        self.section_name_entry.delete(0, tk.END)

    def add_point(self):
        point_name = self.point_name_entry.get()
        section_name = self.point_section_name_combobox.get()

        if not point_name.strip():
            messagebox.showerror("Error", "El nombre del punto no puede estar en blanco.")
            return

        if any(p.punto == point_name for p in self.points):
            messagebox.showerror("Error", f"El punto {point_name} ya existe.")
            return

        if not section_name.strip():
            messagebox.showerror("Error", "Debe seleccionar un apartado para el punto.")
            return

        target_section = next((s for s in self.sections if s.apartado == section_name), None)
        if target_section is None:
            messagebox.showerror("Error", f"No se encontró el apartado: {section_name}")
            return

        point = puntos(point_name)
        self.points.append(point)
        self.discussion_point_name_combobox['values'] = [p.punto for p in self.points]

        messagebox.showinfo("Éxito", f"Punto añadido: {point_name} al apartado {section_name}")

        self.point_name_entry.delete(0, tk.END)
        self.point_section_name_combobox.delete(0, tk.END)

    def add_discussion(self):
        discussion_text = self.discussion_name_entry.get()
        discussion_participant_name = self.discussion_participant_name_combobox.get()
        point_name = self.discussion_point_name_combobox.get()



        discussion_participant = next((p for p in self.participants if " ".join([p.nombre, p.apellido1, p.apellido2]) == discussion_participant_name), None)
        if discussion_participant is None:
            messagebox.showerror("Error", f"No se encontró el participante: {discussion_participant_name}")
            return

        target_point = next((p for p in self.points if p.punto == point_name), None)
        if target_point is None:
            messagebox.showerror("Error", f"No se encontró el punto: {point_name}")
            return

        discussion = discusion(discussion_participant, discussion_text)

        if target_point.discusiones is None:
            target_point.discusiones = discussion
        else:
            last_discussion = target_point.discusiones
            while last_discussion.sig is not None:
                last_discussion = last_discussion.sig
            last_discussion.sig = discussion

        messagebox.showinfo("Éxito", f"Discusión añadida: {discussion_text} por {discussion_participant_name} en el punto {point_name}")

        # Agregar una nueva fila a la tabla con la transcripción de la discusión, el participante y el punto
        self.add_discussion_row(discussion_text, discussion_participant_name, point_name)

    def add_discussion_row(self, discussion_text, participant_name, point_name):
        self.discussion_treeview.insert("", "end", values=(discussion_text, participant_name, point_name))

    def open_new_window(self):
        # Crear una nueva ventana
        new_window = tk.Toplevel(self.root)
        new_window.geometry("300x200")

        # Agregar contenido a la nueva ventana
        label = tk.Label(new_window, text="Mantenimiento de la agenda")
        label.pack()

        # Botones de mantenimiento
        participant_maintenance_button = tk.Button(new_window, text="Mantenimiento de Participantes", command=self.open_participant_maintenance)
        section_maintenance_button = tk.Button(new_window, text="Mantenimiento de Apartados", command=self.open_section_maintenance)
        point_maintenance_button = tk.Button(new_window, text="Mantenimiento de Puntos", command=self.open_point_maintenance)
        agenda_maintenance_button = tk.Button(new_window, text="Mantenimiento de Agenda", command=self.open_agenda_maintenance)

        participant_maintenance_button.pack()
        section_maintenance_button.pack()
        point_maintenance_button.pack()
        agenda_maintenance_button.pack()

    def open_participant_maintenance(self):
        participant_window = tk.Toplevel(self.root)
        participant_window.geometry("400x400")

        # Creando la combobox en la ventana de mantenimiento de participantes.
        self.participant_maintenance_combobox = ttk.Combobox(participant_window)
        self.participant_maintenance_combobox['values'] = [" ".join([p.nombre, p.apellido1, p.apellido2]) for p in self.participants]
        self.participant_maintenance_combobox.pack()

        # Labels y campos de entrada para agregar nuevos participantes.
        tk.Label(participant_window, text="Nombre del nuevo participante:").pack()
        self.new_participant_name_entry = tk.Entry(participant_window)
        self.new_participant_name_entry.pack()

        tk.Label(participant_window, text="Primer apellido del nuevo participante:").pack()
        self.new_participant_surname1_entry = tk.Entry(participant_window)
        self.new_participant_surname1_entry.pack()

        tk.Label(participant_window, text="Segundo apellido del nuevo participante:").pack()
        self.new_participant_surname2_entry = tk.Entry(participant_window)
        self.new_participant_surname2_entry.pack()

        # Botón para agregar un nuevo participante.
        add_button = tk.Button(participant_window, text="Añadir Participante", command=self.add_participant_from_maintenance)
        add_button.pack()

        # Botón para eliminar un participante existente.
        delete_button = tk.Button(participant_window, text="Eliminar Participante", command=self.delete_participant_from_maintenance)
        delete_button.pack()

    def add_participant_from_maintenance(self):
        def add_participant():
            _name = self.new_participant_name_entry.get()
            _surname1 = self.new_participant_surname1_entry.get()
            _surname2 = self.new_participant_surname2_entry.get()

            # Verificar si el participante ya existe
            if any(p.nombre == _name and p.apellido1 == _surname1 and p.apellido2 == _surname2 for p in self.participants):
                messagebox.showerror("Error", f"El participante {_name} {_surname1} {_surname2} ya existe.")
                return

            participant = persona(_name, _surname1, _surname2)
            self.participants.append(participant)
            self.discussion_participant_name_combobox['values'] = [" ".join([p.nombre, p.apellido1, p.apellido2]) for p in self.participants]

            # Limpiar los campos de entrada.
            self.new_participant_name_entry.delete(0, tk.END)
            self.new_participant_surname1_entry.delete(0, tk.END)
            self.new_participant_surname2_entry.delete(0, tk.END)

            messagebox.showinfo("Éxito", f"Participante añadido: {_name} {_surname1} {_surname2}")

            # Actualizar la combobox en la ventana de mantenimiento de participantes
            self.update_participant_combobox()

        if not self.new_participant_name_entry.get() or not self.new_participant_surname1_entry.get() or not self.new_participant_surname2_entry.get():
            messagebox.showerror("Error", "Debes llenar todos los campos de entrada.")
        else:
            add_participant()
    def delete_participant_from_maintenance(self):
        def delete_participant():
            _name = self.participant_maintenance_combobox.get()
            self.participants = [p for p in self.participants if " ".join([p.nombre, p.apellido1, p.apellido2]) != _name]
            self.discussion_participant_name_combobox['values'] = [" ".join([p.nombre, p.apellido1, p.apellido2]) for p in self.participants]

            # Limpiar el campo de entrada y actualizar la combobox en la ventana de mantenimiento de participantes
            self.participant_maintenance_combobox.set('')
            self.update_participant_combobox()

        if not self.participant_maintenance_combobox.get():
            messagebox.showerror("Error", "Debes seleccionar un participante para eliminar.")
        else:
            delete_participant()
    def update_participant_combobox(self):
        self.participant_maintenance_combobox['values'] = [" ".join([p.nombre, p.apellido1, p.apellido2]) for p in self.participants]
    
    def open_section_maintenance(self):
        section_window = tk.Toplevel(self.root)
        section_window.geometry("400x400")

        # Creando la combobox en la ventana de mantenimiento de apartados.
        self.section_maintenance_combobox = ttk.Combobox(section_window)
        self.section_maintenance_combobox['values'] = [s.apartado for s in self.sections]
        self.section_maintenance_combobox.pack()

        # Labels y campos de entrada para agregar nuevos apartados.
        tk.Label(section_window, text="Nombre del nuevo apartado:").pack()
        self.new_section_name_entry = tk.Entry(section_window)
        self.new_section_name_entry.pack()

        # Botón para agregar un nuevo apartado.
        add_button = tk.Button(section_window, text="Añadir Apartado", command=self.add_section_from_maintenance)
        add_button.pack()

        # Botón para eliminar un apartado existente.
        delete_button = tk.Button(section_window, text="Eliminar Apartado", command=self.delete_section_from_maintenance)
        delete_button.pack()

    def add_section_from_maintenance(self):
        def add_section():
            _name = self.new_section_name_entry.get()

            if any(s.apartado == _name for s in self.sections):
                messagebox.showerror("Error", f"El apartado {_name} ya existe.")
                return

            section = apartados(_name)
            self.sections.append(section)
            self.point_section_name_combobox['values'] = [s.apartado for s in self.sections]
            self.section_maintenance_combobox['values'] = [s.apartado for s in self.sections]

            messagebox.showinfo("Éxito", f"Apartado añadido: {_name}")

            self.new_section_name_entry.delete(0, tk.END)

        if not self.new_section_name_entry.get():
            messagebox.showerror("Error", "Debes llenar el campo de entrada.")
        else:
            add_section()

    def delete_section_from_maintenance(self):
        def delete_section():
            _name = self.section_maintenance_combobox.get()
            self.sections = [s for s in self.sections if s.apartado != _name]
            self.point_section_name_combobox['values'] = [s.apartado for s in self.sections]
            self.section_maintenance_combobox['values'] = [s.apartado for s in self.sections]

        if not self.section_maintenance_combobox.get():
            messagebox.showerror("Error", "Debes seleccionar un apartado para eliminar.")
        else:
            delete_section()
    def open_point_maintenance(self):
        point_window = tk.Toplevel(self.root)
        point_window.geometry("400x400")

        self.point_maintenance_combobox = ttk.Combobox(point_window)
        self.point_maintenance_combobox.pack()

        delete_point_button = tk.Button(point_window, text="Eliminar Punto", command=self.delete_point_from_maintenance)
        delete_point_button.pack()

        self.update_point_combobox()

        # Labels y campos de entrada para agregar nuevos puntos.
        tk.Label(point_window, text="Nombre del nuevo punto:").pack()
        self.new_point_name_entry = tk.Entry(point_window)
        self.new_point_name_entry.pack()

        tk.Label(point_window, text="Apartado asociado:").pack()
        self.new_point_section_combobox = ttk.Combobox(point_window)
        self.new_point_section_combobox['values'] = [s.apartado for s in self.sections]
        self.new_point_section_combobox.pack()

        # Botón para agregar un nuevo punto.
        add_point_button = tk.Button(point_window, text="Añadir Punto", command=self.add_point_from_maintenance)
        add_point_button.pack()

    def add_point_from_maintenance(self):
        def add_point():
            point_name = self.new_point_name_entry.get()
            section_name = self.new_point_section_combobox.get()

            if any(p.punto == point_name for p in self.points):
                messagebox.showerror("Error", f"El punto {point_name} ya existe.")
                return

            target_section = next((s for s in self.sections if s.apartado == section_name), None)
            if target_section is None:
                messagebox.showerror("Error", f"No se encontró el apartado: {section_name}")
                return

            point = puntos(point_name)
            self.points.append(point)
            self.discussion_point_name_combobox['values'] = [p.punto for p in self.points]

            messagebox.showinfo("Éxito", f"Punto añadido: {point_name} al apartado {section_name}")

            self.new_point_name_entry.delete(0, tk.END)
            self.new_point_section_combobox.delete(0, tk.END)

            self.update_point_combobox()

        if not self.new_point_name_entry.get() or not self.new_point_section_combobox.get():
            messagebox.showerror("Error", "Debes llenar todos los campos de entrada.")
        else:
            add_point()

    def update_point_combobox(self, event=None):
        point_names = [p.punto for p in self.points]
        self.point_maintenance_combobox['values'] = point_names

    def delete_point_from_maintenance(self):
        def delete_point():
            selected_point = self.point_maintenance_combobox.get()
            self.points = [p for p in self.points if p.punto != selected_point]
            self.update_point_combobox()

        if not self.point_maintenance_combobox.get():
            messagebox.showerror("Error", "Debes seleccionar un punto para eliminar.")
        else:
            delete_point()

    def open_agenda_maintenance(self):
        agenda_maintenance_window = tk.Toplevel(self.root)
        agenda_maintenance_window.geometry("400x400")

        self.agenda_maintenance_combobox = ttk.Combobox(agenda_maintenance_window)
        self.agenda_maintenance_combobox['values'] = self.agendas
        self.agenda_maintenance_combobox.pack()
        add_agenda_button = tk.Button(agenda_maintenance_window, text="Añadir Título de Agenda", command=self.add_agenda_from_maintenance)
        add_agenda_button.pack()

    def add_agenda_from_maintenance(self):
        new_agenda_title = self.agenda_maintenance_combobox.get()
        date = datetime.datetime.now().strftime("%Y-%m-%d")  # Obtener la fecha actual

        if not new_agenda_title:
            messagebox.showerror("Error", "Debes ingresar un título de agenda.")
            return

        if new_agenda_title in self.agendas:
            messagebox.showerror("Error", f"El título de la agenda '{new_agenda_title}' ya existe.")
            return

        self.agendas.append(f"{new_agenda_title} - {date}")  # Combinar título y fecha
        self.agenda_maintenance_combobox['values'] = self.agendas

        messagebox.showinfo("Éxito", f"Título de la agenda añadido: '{new_agenda_title}' - {date}")
    
root = tk.Tk()
app = App(root)
root.mainloop()
