import tkinter as tk
from tkinter import ttk
from agenda import agenda, persona, apartados, puntos, discusion  # Asegúrate de reemplazar 'modulo_existente' con el nombre de tu módulo actual

class App:
    def __init__(self, root):
        self.agenda = agenda()

        self.participants = []
        self.sections = []
        self.points = []

        # Definición de los widgets de entrada y botones
        self.agenda_title_label = tk.Label(root, text="Título de la Agenda")
        self.agenda_title_entry = tk.Entry(root)
        self.agenda_title_button = tk.Button(root, text="Añadir Título de la Agenda", command=self.set_agenda_title)

        self.participant_name_label = tk.Label(root, text="Nombre del Participante")
        self.participant_name_entry = tk.Entry(root)
        self.participant_surname1_label = tk.Label(root, text="Primer Apellido del Participante")
        self.participant_surname1_entry = tk.Entry(root)
        self.participant_surname2_label = tk.Label(root, text="Segundo Apellido del Participante")
        self.participant_surname2_entry = tk.Entry(root)
        self.participant_button = tk.Button(root, text="Añadir Participante", command=self.add_participant)

        self.section_name_label = tk.Label(root, text="Nombre del Apartado")
        self.section_name_entry = tk.Entry(root)
        self.section_button = tk.Button(root, text="Añadir Apartado", command=self.add_section)

        self.point_name_label = tk.Label(root, text="Nombre del Punto")
        self.point_name_entry = tk.Entry(root)
        self.point_section_name_label = tk.Label(root, text="Apartado Asociado al Punto")
        self.point_section_name_combobox = ttk.Combobox(root)
        self.point_button = tk.Button(root, text="Añadir Punto", command=self.add_point)

        self.discussion_name_label = tk.Label(root, text="Transcripción de la Discusión")
        self.discussion_name_entry = tk.Entry(root)
        self.discussion_participant_name_label = tk.Label(root, text="Nombre del Participante que Discute")
        self.discussion_participant_name_combobox = ttk.Combobox(root)
        self.discussion_point_name_label = tk.Label(root, text="Punto Asociado a la Discusión")
        self.discussion_point_name_combobox = ttk.Combobox(root)
        self.discussion_button = tk.Button(root, text="Añadir Discusión", command=self.add_discussion)

        # Empaquetar los widgets para que se muestren
        self.agenda_title_label.pack()
        self.agenda_title_entry.pack()
        self.agenda_title_button.pack()

        self.participant_name_label.pack()
        self.participant_name_entry.pack()
        self.participant_surname1_label.pack()
        self.participant_surname1_entry.pack()
        self.participant_surname2_label.pack()
        self.participant_surname2_entry.pack()
        self.participant_button.pack()

        self.section_name_label.pack()
        self.section_name_entry.pack()
        self.section_button.pack()

        self.point_name_label.pack()
        self.point_name_entry.pack()
        self.point_section_name_label.pack()
        self.point_section_name_combobox.pack()
        self.point_button.pack()

        self.discussion_name_label.pack()
        self.discussion_name_entry.pack()
        self.discussion_participant_name_label.pack()
        self.discussion_participant_name_combobox.pack()
        self.discussion_point_name_label.pack()
        self.discussion_point_name_combobox.pack()
        self.discussion_button.pack()

    

    def set_agenda_title(self):
        self.agenda.titulo = self.agenda_title_entry.get()
        print(f'Título de la Agenda establecido: {self.agenda.titulo}')

    def add_participant(self):
        _name = self.participant_name_entry.get()
        _surname1 = self.participant_surname1_entry.get()
        _surname2 = self.participant_surname2_entry.get()

        participant = persona(_name, _surname1, _surname2)
        self.participants.append(participant)
        self.discussion_participant_name_combobox['values'] = [p.nombre for p in self.participants]

        if self.agenda.participantes is None:
            self.agenda.participantes = participant
        else:
            last_participant = self.agenda.participantes
            while last_participant.sig is not None:
                last_participant = last_participant.sig
            last_participant.sig = participant

        print(f'Participante añadido: {_name} {_surname1} {_surname2}')

    def add_section(self):
        _name = self.section_name_entry.get()

        section = apartados(_name)
        self.sections.append(section)
        self.point_section_name_combobox['values'] = [s.apartado for s in self.sections]

        if self.agenda.apartados is None:
            self.agenda.apartados = section
        else:
            last_section = self.agenda.apartados
            while last_section.sig is not None:
                last_section = last_section.sig
            last_section.sig = section

        print(f'Apartado añadido: {_name}')

    def add_point(self):
        point_name = self.point_name_entry.get()
        section_name = self.point_section_name_combobox.get()

        point = puntos(point_name)
        self.points.append(point)
        self.discussion_point_name_combobox['values'] = [p.punto for p in self.points]

        target_section = next((s for s in self.sections if s.apartado == section_name), None)
        if target_section is None:
            print(f'No se encontró el apartado: {section_name}')
            return

        if target_section.puntos is None:
            target_section.puntos = point
        else:
            last_point = target_section.puntos
            while last_point.sig is not None:
                last_point = last_point.sig
            last_point.sig = point

        print(f'Punto añadido: {point_name} al apartado {section_name}')

    def add_discussion(self):
        discussion_text = self.discussion_name_entry.get()
        discussion_participant_name = self.discussion_participant_name_combobox.get()
        point_name = self.discussion_point_name_combobox.get()

        discussion_participant = next((p for p in self.participants if p.nombre == discussion_participant_name), None)
        if discussion_participant is None:
            print(f'No se encontró el participante: {discussion_participant_name}')
            return

        target_point = next((p for p in self.points if p.punto == point_name), None)
        if target_point is None:
            print(f'No se encontró el punto: {point_name}')
            return

        discussion = discusion(discussion_participant, discussion_text)

        if target_point.discusiones is None:
            target_point.discusiones = discussion
        else:
            last_discussion = target_point.discusiones
            while last_discussion.sig is not None:
                last_discussion = last_discussion.sig
            last_discussion.sig = discussion

        print(f'Discusión añadida: {discussion_text} por {discussion_participant_name} en el punto {point_name}')

root = tk.Tk()
root.geometry("450x550")  # Establecer el tamaño de la ventana a 800x600 píxeles

app = App(root)
root.mainloop()