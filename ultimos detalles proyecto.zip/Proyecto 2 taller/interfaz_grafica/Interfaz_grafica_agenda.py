import sys
from typing import Dict
from PyQt5.QtWidgets import QApplication,QTableWidget,QTableWidgetItem,QInputDialog, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from PyQt5.QtWidgets import QApplication,QTextEdit,QFileDialog, QMainWindow, QLabel, QPushButton, QLineEdit, QVBoxLayout, QHBoxLayout, QWidget, QInputDialog, QListWidget, QListWidgetItem, QMessageBox
from Interfaz_grafica_participantes import RegistrarParticipantes
class Registro_agenda(QWidget):
    """
    Clase Registro_agenda que hereda de QWidget y permite registrar apartados y subtemas en una agenda.
    """
    def __init__(self):
        """
        Constructor de la clase Registro_agenda.
        Inicializa los widgets y establece las conexiones de los botones.
        """
        super().__init__()

        self.salida: Dict[str, Dict[str, bool]] = {}
        # Inicialización de widgets
        self.apartado_label = QLabel("Nombre del apartado:")
        self.apartado_input = QLineEdit()
        self.subtema_label = QLabel("Nombre del subtema: ")
        self.subtema_input = QLineEdit()
        self.agregarAp_button = QPushButton("Agregar apartado")
        self.agregarSub_button = QPushButton("Agregar subtema")
        self.editarSub_button = QPushButton("Editar subtema")
        self.eliminarSub_button = QPushButton("Eliminar subtema")
        self.terminar_button = QPushButton("Terminar registro")
        # Conexiones de botones
        self.agregarAp_button.clicked.connect(self.agregar_apartado)
        self.agregarSub_button.clicked.connect(self.agregar_subtema)
        self.editarSub_button.clicked.connect(self.editar_subtema)
        self.eliminarSub_button.clicked.connect(self.eliminar_subtema)
        self.terminar_button.clicked.connect(self.terminar_registro)
        # Diseño de la ventana
        vbox = QVBoxLayout()
        hbox1 = QHBoxLayout()
        hbox1.addWidget(self.apartado_label)
        hbox1.addWidget(self.apartado_input)
        vbox.addLayout(hbox1)
        hbox2 = QHBoxLayout()
        hbox2.addWidget(self.subtema_label)
        hbox2.addWidget(self.subtema_input)
        vbox.addLayout(hbox2)
        vbox.addWidget(self.agregarAp_button)
        vbox.addWidget(self.agregarSub_button)
        vbox.addWidget(self.editarSub_button)
        vbox.addWidget(self.eliminarSub_button)
        vbox.addWidget(self.terminar_button)

        self.setLayout(vbox)
        self.setWindowTitle("Registro de Agenda")

    def agregar_apartado(self):
        """
        Agrega un apartado a la agenda.
        """
        apartado = self.apartado_input.text()
        if apartado == "":
            QMessageBox.warning(self, "Error", "Debe ingresar un apartado.")
        elif apartado.lower() == "eliminar":
            QMessageBox.warning(self, "Error", "El apartado 'eliminar' no está permitido.")
        elif apartado.lower() == "fin":
            self.terminar_registro()
        elif apartado in self.salida:
            QMessageBox.warning(self, "Error", f"El apartado '{apartado}' ya está en la lista.")
        else:
            self.salida[apartado] = {}
            QMessageBox.information(self, "Registro", f"Se ha registrado a {apartado} en la agenda.")
            self.apartado_input.setText("")

    def agregar_subtema(self):
        """
        Agrega un subtema a un apartado en la agenda.

        Si el usuario no ha seleccionado un apartado, no ha ingresado un subtema o si el subtema que intenta agregar ya existe en la lista, se mostrará un mensaje de error.
        El usuario puede ingresar "eliminar" como subtema, pero no puede ingresar "fin" ya que esta opción está reservada para terminar el registro de la agenda.
        """
        apartado = self.apartado_input.text()
        subtema = self.subtema_input.text()
        if apartado == "":
            QMessageBox.warning(self, "Error", "Debe seleccionar un apartado.")
        elif subtema == "":
            QMessageBox.warning(self, "Error", "Debe ingresar un subtema.")
        elif subtema.lower() == "eliminar":
            QMessageBox.warning(self, "Error", "El subtema 'eliminar' no está permitido.")
        elif subtema.lower() == "fin":
            self.terminar_registro()
        elif apartado in self.salida and subtema in self.salida[apartado]:
            QMessageBox.warning(self, "Error", f"El subtema '{subtema}' ya está en la lista.")
        else:
            self.salida[apartado][subtema] = True
            QMessageBox.information(self, "Registro", f"Se ha registrado a {subtema} en el apartado {apartado}.")
            self.subtema_input.setText("")

    def editar_subtema(self):
        """
        Edita el nombre de un subtema en un apartado de la agenda.

        Primero se muestra una ventana de selección de apartado. Si se selecciona un apartado, se muestra otra ventana de selección de subtema a editar.
        Si se selecciona un subtema, se muestra una ventana para ingresar el nuevo nombre del subtema. Si se ingresa un nombre válido y se acepta, se edita el
        subtema y se muestra un mensaje informativo.

        Returns:
            None
        """
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "No hay apartados para editar subtemas.")
        else:
            apartado, ok = QInputDialog.getItem(self, "Editar subtema", "Seleccione el apartado: ", list(self.salida.keys()), 0, False)
            if ok:
                if len(self.salida[apartado]) == 0:
                    QMessageBox.warning(self, "Error", "No hay subtemas para editar en el apartado seleccionado.")
                else:
                    subtema_actual, ok = QInputDialog.getItem(self, "Editar subtema", "Seleccione el subtema a editar: ", list(self.salida[apartado].keys()), 0, False)
                    if ok:
                        subtema_nuevo, ok = QInputDialog.getText(self, "Editar subtema", "Ingrese el nuevo nombre del subtema:")
                        if ok and subtema_nuevo != "":
                            del self.salida[apartado][subtema_actual]
                            self.salida[apartado][subtema_nuevo] = True
                            QMessageBox.information(self, "Agenda", f"Se ha editado el subtema '{subtema_actual}' a '{subtema_nuevo}'")

    def eliminar_subtema(self):
        """
        Función para eliminar un subtema de un apartado en la agenda.

        Args:
            self: La instancia actual de la clase.

        Returns:
            None.

        Raises:
            None.
        """
        # Verificar que existan apartados para eliminar subtemas.
        if len(self.salida) == 0:
            # Si no hay apartados, mostrar un mensaje de error.
            QMessageBox.warning(self, "Error", "No hay apartados para eliminar subtemas.")
        else:
            # Si hay apartados, permitir al usuario seleccionar el apartado y el subtema a eliminar.
            apartado, ok = QInputDialog.getItem(self, "Eliminar subtema", "Seleccione el apartado: ", list(self.salida.keys()), 0, False)
            if ok:
                # Verificar que existan subtemas en el apartado seleccionado.
                if len(self.salida[apartado]) == 0:
                    # Si no hay subtemas en el apartado seleccionado, mostrar un mensaje de error.
                    QMessageBox.warning(self, "Error", "No hay subtemas para eliminar en el apartado seleccionado.")
                else:
                    # Si hay subtemas en el apartado seleccionado, permitir al usuario seleccionar el subtema a eliminar.
                    eliminado, ok = QInputDialog.getItem(self, "Eliminar subtema", "Seleccione el subtema a eliminar: ", list(self.salida[apartado].keys()), 0, False)
                    if ok:
                        # Eliminar el subtema seleccionado del apartado.
                        del self.salida[apartado][eliminado]
                        # Mostrar un mensaje informativo de que se ha eliminado el subtema.
                        QMessageBox.information(self, "Agenda", f"Se ha eliminado a {eliminado} de la lista")

def terminar_registro(self):
    """
    Función para terminar el registro de la agenda y cerrar la ventana actual.
    
    Args:
        self: La instancia actual de la clase.

    Returns:
        None.

    Raises:
        None.
    """
    
    # Verificar que se hayan registrado subtemas.
    if len(self.salida) == 0:
        # Si no hay subtemas registrados, mostrar un mensaje de error.
        QMessageBox.warning(self, "Error", "Debe haber al menos un subtema registrado.")
    else:
        # Si hay subtemas registrados, cerrar la ventana actual y abrir la ventana para registrar participantes.
        self.close()
        self.registro_participantes = RegistrarParticipantes()
        self.registro_participantes.show()
