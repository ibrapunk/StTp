import sys
from typing import Dict
from PyQt5.QtWidgets import QApplication,QTableWidget,QTableWidgetItem,QInputDialog, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from PyQt5.QtWidgets import QApplication,QTextEdit,QFileDialog, QMainWindow, QLabel, QPushButton, QLineEdit, QVBoxLayout, QHBoxLayout, QWidget, QInputDialog, QListWidget, QListWidgetItem, QMessageBox
from Interfaz_grafica_agenda import Registro_agenda
class RegistrarParticipantes(QWidget):
    """
    Clase que define la ventana de registro de participantes.

        Atributos:
    salida (Dict[str, bool]): Diccionario que contiene los nombres de los participantes registrados.
    nombre_label (QLabel): Etiqueta para el nombre del participante.
    nombre_input (QLineEdit): Campo de entrada para el nombre del participante.
    agregar_button (QPushButton): Botón para agregar un participante a la lista.
    eliminar_button (QPushButton): Botón para eliminar un participante de la lista.
    terminar_button (QPushButton): Botón para terminar el registro.

    Métodos:
    __init__(self): Inicializa la ventana de registro.
    agregar_participante(self): Agrega un participante a la lista.
    eliminar_participante(self): Elimina un participante de la lista.
    terminar_registro(self): Cierra la ventana de registro y finaliza el programa.
    """

    def __init__(self):
        """
        Inicializa la ventana de registro de participantes.

        Atributos:
        salida (Dict[str, bool]): Diccionario que contiene los nombres de los participantes registrados.
        nombre_label (QLabel): Etiqueta para el nombre del participante.
        nombre_input (QLineEdit): Campo de entrada para el nombre del participante.
        agregar_button (QPushButton): Botón para agregar un participante a la lista.
        eliminar_button (QPushButton): Botón para eliminar un participante de la lista.
        terminar_button (QPushButton): Botón para terminar el registro.
        """
        super().__init__()

        # Inicializa la lista de salida.
        self.salida: Dict[str, bool] = {}

        # Crea los widgets de la interfaz gráfica.
        self.nombre_label = QLabel("Nombre del participante:")
        self.nombre_input = QLineEdit()
        self.agregar_button = QPushButton("Agregar participante")
        self.eliminar_button = QPushButton("Eliminar participante")
        self.terminar_button = QPushButton("Terminar registro")

        # Conecta los botones con sus métodos correspondientes.
        self.agregar_button.clicked.connect(self.agregar_participante)
        self.eliminar_button.clicked.connect(self.eliminar_participante)
        self.terminar_button.clicked.connect(self.terminar_registro)

        # Crea el layout y agrega los widgets.
        vbox = QVBoxLayout()
        hbox = QHBoxLayout()
        hbox.addWidget(self.nombre_label)
        hbox.addWidget(self.nombre_input)
        vbox.addLayout(hbox)
        vbox.addWidget(self.agregar_button)
        vbox.addWidget(self.eliminar_button)
        vbox.addWidget(self.terminar_button)

        # Establece el layout.
        self.setLayout(vbox)
        self.setWindowTitle("Registro de participantes")

    def agregar_participante(self):
        """
        Agrega el nombre del participante a la lista de salida si es válido.

        Args:
            self: La instancia actual de la clase.

        Returns:
            None.
        """
        nombre = self.nombre_input.text()

        if nombre == "":
            QMessageBox.warning(self, "Error", "Debe ingresar un nombre.")
        elif nombre.lower() == "eliminar":
            QMessageBox.warning(self, "Error", "El nombre 'eliminar' no está permitido.")
        elif nombre.lower() == "fin":
            self.terminar_registro()
        elif nombre in self.salida:
            QMessageBox.warning(self, "Error", f"El nombre '{nombre}' ya está en la lista.")
        else:
            self.salida[nombre] = True
            QMessageBox.information(self, "Registro", f"Se ha registrado a {nombre} en la lista.")
            self.nombre_input.setText("")

    def eliminar_participante(self):
        """
        Elimina el participante seleccionado de la lista de salida.

        Args:
            self: La instancia actual de la clase.

        Returns:
            None.
        """
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "No hay participantes para eliminar.")
        else:
            eliminado, ok = QInputDialog.getItem(self, "Eliminar participante", "Seleccione el participante a eliminar:", self.salida.keys(), 0, False)
            if ok:
                del self.salida[eliminado]
                QMessageBox.information(self, "Registro", f"Se ha eliminado a {eliminado} de la lista.")

    def terminar_registro(self):
        """
        Finaliza el registro y cierra la ventana actual si hay al menos un participante registrado.

        Args:
            self: La instancia actual de la clase Registro_agenda.

        Returns:
            None.
        """
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "Debe haber al menos un participante registrado.")
        else:
            self.close()


if __name__ == "__main__":
    """
    Inicia la aplicación y muestra la ventana del registro de agenda.
    """
    app = QApplication([])
    registroA = Registro_agenda()
    registroA.show()
    app.exec_()