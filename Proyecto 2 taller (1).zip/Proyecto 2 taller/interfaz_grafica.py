import sys
from typing import Dict
from PyQt5.QtWidgets import QApplication,QInputDialog, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QPushButton, QLineEdit, QVBoxLayout, QHBoxLayout, QWidget, QInputDialog, QListWidget, QListWidgetItem, QMessageBox

class Registro_agenda(QWidget):
    def __init__(self):
        super().__init__()

        self.salida: Dict[str, Dict[str, bool]] = {}

        self.apartado_label = QLabel("Nombre del apartado:")
        self.apartado_input = QLineEdit()
        self.subtema_label = QLabel("Nombre del subtema: ")
        self.subtema_input = QLineEdit()
        self.agregarAp_button = QPushButton("Agregar apartado")
        self.agregarSub_button = QPushButton("Agregar subtema")
        self.editarSub_button = QPushButton("Editar subtema")
        self.eliminarSub_button = QPushButton("Eliminar subtema")
        self.terminar_button = QPushButton("Terminar registro")

        self.agregarAp_button.clicked.connect(self.agregar_apartado)
        self.agregarSub_button.clicked.connect(self.agregar_subtema)
        self.editarSub_button.clicked.connect(self.editar_subtema)
        self.eliminarSub_button.clicked.connect(self.eliminar_subtema)
        self.terminar_button.clicked.connect(self.terminar_registro)

        vbox = QVBoxLayout()
        hbox1 = QHBoxLayout()
        hbox1.addWidget(self.apartado_label)
        hbox1.addWidget(self.apartado_input)
        vbox.addLayout(hbox1)
        hbox2 = QHBoxLayout()
        hbox2.addWidget(self.subtema_label)
        hbox2.addWidget(self.subtema_input)
        vbox.addLayout(hbox2)
        vbox.addWidget(self.agregarAp_button)
        vbox.addWidget(self.agregarSub_button)
        vbox.addWidget(self.editarSub_button)
        vbox.addWidget(self.eliminarSub_button)
        vbox.addWidget(self.terminar_button)

        self.setLayout(vbox)
        self.setWindowTitle("Registro de Agenda")

    def agregar_apartado(self):
        apartado = self.apartado_input.text()
        if apartado == "":
            QMessageBox.warning(self, "Error", "Debe ingresar un apartado.")
        elif apartado.lower() == "eliminar":
            QMessageBox.warning(self, "Error", "El apartado 'eliminar' no está permitido.")
        elif apartado.lower() == "fin":
            self.terminar_registro()
        elif apartado in self.salida:
            QMessageBox.warning(self, "Error", f"El apartado '{apartado}' ya está en la lista.")
        else:
            self.salida[apartado] = {}
            QMessageBox.information(self, "Registro", f"Se ha registrado a {apartado} en la agenda.")
            self.apartado_input.setText("")

    def agregar_subtema(self):
        apartado = self.apartado_input.text()
        subtema = self.subtema_input.text()
        if apartado == "":
            QMessageBox.warning(self, "Error", "Debe seleccionar un apartado.")
        elif subtema == "":
            QMessageBox.warning(self, "Error", "Debe ingresar un subtema.")
        elif subtema.lower() == "eliminar":
            QMessageBox.warning(self, "Error", "El subtema 'eliminar' no está permitido.")
        elif subtema.lower() == "fin":
            self.terminar_registro()
        elif apartado in self.salida and subtema in self.salida[apartado]:
            QMessageBox.warning(self, "Error", f"El subtema '{subtema}' ya está en la lista.")
        else:
            self.salida[apartado][subtema] = True
            QMessageBox.information(self, "Registro", f"Se ha registrado a {subtema} en el apartado {apartado}.")
            self.subtema_input.setText("")

    def editar_subtema(self):
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "No hay apartados para editar subtemas.")
        else:
            apartado, ok = QInputDialog.getItem(self, "Editar subtema", "Seleccione el apartado: ", list(self.salida.keys()), 0, False)
            if ok:
                if len(self.salida[apartado]) == 0:
                    QMessageBox.warning(self, "Error", "No hay subtemas para editar en el apartado seleccionado.")
                else:
                    subtema_actual, ok = QInputDialog.getItem(self, "Editar subtema", "Seleccione el subtema a editar: ", list(self.salida[apartado].keys()), 0, False)
                    if ok:
                        subtema_nuevo, ok = QInputDialog.getText(self, "Editar subtema", "Ingrese el nuevo nombre del subtema:")
                        if ok and subtema_nuevo != "":
                            del self.salida[apartado][subtema_actual]
                            self.salida[apartado][subtema_nuevo] = True
                            QMessageBox.information(self, "Agenda", f"Se ha editado el subtema '{subtema_actual}' a '{subtema_nuevo}'")

    def eliminar_subtema(self):
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "No hay apartados para eliminar subtemas.")
        else:
            apartado, ok = QInputDialog.getItem(self, "Eliminar subtema", "Seleccione el apartado: ", list(self.salida.keys()), 0, False)
            if ok:
                if len(self.salida[apartado]) == 0:
                    QMessageBox.warning(self, "Error", "No hay subtemas para eliminar en el apartado seleccionado.")
                else:
                    eliminado, ok = QInputDialog.getItem(self, "Eliminar subtema", "Seleccione el subtema a eliminar: ", list(self.salida[apartado].keys()), 0, False)
                    if ok:
                        del self.salida[apartado][eliminado]
                        QMessageBox.information(self, "Agenda", f"Se ha eliminado a {eliminado} de la lista")

    def terminar_registro(self):
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "Debe haber al menos un subtema registrado.")
        else:
            self.close()
        

if __name__ == "__main__":
    app = QApplication([])
    registro = Registro_agenda()
    registro.show()
    app.exec_()














class RegistrarParticipantes(QWidget):
    def __init__(self):
        super().__init__()

        # Inicializar la variable de salida como un diccionario vacío
        self.salida: Dict[str, bool] = {}

        # Crear los elementos de la interfaz gráfica
        self.nombre_label = QLabel("Nombre del participante:")
        self.nombre_input = QLineEdit()
        self.agregar_button = QPushButton("Agregar participante")
        self.eliminar_button = QPushButton("Eliminar participante")
        self.terminar_button = QPushButton("Terminar registro")

        # Configurar los elementos de la interfaz gráfica
        self.agregar_button.clicked.connect(self.agregar_participante)
        self.eliminar_button.clicked.connect(self.eliminar_participante)
        self.terminar_button.clicked.connect(self.terminar_registro)

        # Crear el diseño de la interfaz gráfica
        vbox = QVBoxLayout()
        hbox = QHBoxLayout()
        hbox.addWidget(self.nombre_label)
        hbox.addWidget(self.nombre_input)
        vbox.addLayout(hbox)
        vbox.addWidget(self.agregar_button)
        vbox.addWidget(self.eliminar_button)
        vbox.addWidget(self.terminar_button)

        # Configurar la ventana
        self.setLayout(vbox)
        self.setWindowTitle("Registro de participantes")

    def agregar_participante(self):
        nombre = self.nombre_input.text()

        if nombre == "":
            QMessageBox.warning(self, "Error", "Debe ingresar un nombre.")
        elif nombre.lower() == "eliminar":
            QMessageBox.warning(self, "Error", "El nombre 'eliminar' no está permitido.")
        elif nombre.lower() == "fin":
            self.terminar_registro()
        elif nombre in self.salida:
            QMessageBox.warning(self, "Error", f"El nombre '{nombre}' ya está en la lista.")
        else:
            self.salida[nombre] = True
            QMessageBox.information(self, "Registro", f"Se ha registrado a {nombre} en la lista.")
            self.nombre_input.setText("")

    def eliminar_participante(self):
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "No hay participantes para eliminar.")
        else:
            eliminado, ok = QInputDialog.getItem(self, "Eliminar participante", "Seleccione el participante a eliminar:", self.salida.keys(), 0, False)
            if ok:
                del self.salida[eliminado]
                QMessageBox.information(self, "Registro", f"Se ha eliminado a {eliminado} de la lista.")

    def terminar_registro(self):
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "Debe haber al menos un participante registrado.")
        else:
            self.close()


if __name__ == "__main__":
    app = QApplication([])
    registro = RegistrarParticipantes()
    registro.show()
    app.exec_()