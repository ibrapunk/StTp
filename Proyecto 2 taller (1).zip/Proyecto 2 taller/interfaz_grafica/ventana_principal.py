import sys
from typing import Dict
from PyQt5.QtWidgets import QApplication,QTableWidget,QTableWidgetItem,QComboBox,QTextEdit,QFileDialog, QMainWindow, QLabel, QPushButton, QLineEdit, QVBoxLayout, QHBoxLayout, QWidget, QInputDialog, QListWidget, QListWidgetItem, QMessageBox
import speech_recognition as sr
from pydub import AudioSegment
from pydub.silence import split_on_silence
class App(QWidget):
    def __init__(self):
        super().__init__()
        self.title = 'Seleccionar carpeta de registro de estado'
        self.left = 10
        self.top = 10
        self.width = 640
        self.height = 480
        self.setStyleSheet("background-color: white;")
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)

        # Botón para iniciar un proyecto nuevo
        self.btn_new_project = QPushButton('Nuevo proyecto', self)
        self.btn_new_project.setGeometry(100, 50, 200, 50)
        self.btn_new_project.clicked.connect(self.new_project)

        # Botón para abrir un proyecto existente
        self.btn_open_project = QPushButton('Abrir proyecto', self)
        self.btn_open_project.setGeometry(340, 50, 200, 50)
        self.btn_open_project.clicked.connect(self.open_project)

        # Etiqueta para mostrar la ruta de la carpeta seleccionada
        self.lbl_selected_folder = QLabel('No se ha seleccionado ninguna carpeta', self)
        self.lbl_selected_folder.setGeometry(100, 120, 400, 50)

        self.show()

    def new_project(self):
        # Lógica para iniciar un proyecto nuevo
        print('Iniciando nuevo proyecto...')
        self.close()
        self.registro_agenda = Registro_agenda()
        self.registro_agenda.show()

    def open_project(self):
        # Lógica para abrir un proyecto existente
        options = QFileDialog.Options()
        options |= QFileDialog.ShowDirsOnly
        folder_path = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta", options=options)
        self.lbl_selected_folder.setText('Carpeta seleccionada: ' + folder_path)