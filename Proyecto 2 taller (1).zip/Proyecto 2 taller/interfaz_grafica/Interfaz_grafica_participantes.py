import sys
from typing import Dict
from PyQt5.QtWidgets import QApplication,QTableWidget,QTableWidgetItem,QInputDialog, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from PyQt5.QtWidgets import QApplication,QTextEdit,QFileDialog, QMainWindow, QLabel, QPushButton, QLineEdit, QVBoxLayout, QHBoxLayout, QWidget, QInputDialog, QListWidget, QListWidgetItem, QMessageBox
from Interfaz_grafica_agenda import Registro_agenda
class RegistrarParticipantes(QWidget):
    def __init__(self):
        super().__init__()

        self.salida: Dict[str, bool] = {}

        self.nombre_label = QLabel("Nombre del participante:")
        self.nombre_input = QLineEdit()
        self.agregar_button = QPushButton("Agregar participante")
        self.eliminar_button = QPushButton("Eliminar participante")
        self.terminar_button = QPushButton("Terminar registro")

        self.agregar_button.clicked.connect(self.agregar_participante)
        self.eliminar_button.clicked.connect(self.eliminar_participante)
        self.terminar_button.clicked.connect(self.terminar_registro)

        vbox = QVBoxLayout()
        hbox = QHBoxLayout()
        hbox.addWidget(self.nombre_label)
        hbox.addWidget(self.nombre_input)
        vbox.addLayout(hbox)
        vbox.addWidget(self.agregar_button)
        vbox.addWidget(self.eliminar_button)
        vbox.addWidget(self.terminar_button)

        self.setLayout(vbox)
        self.setWindowTitle("Registro de participantes")

    def agregar_participante(self):
        nombre = self.nombre_input.text()

        if nombre == "":
            QMessageBox.warning(self, "Error", "Debe ingresar un nombre.")
        elif nombre.lower() == "eliminar":
            QMessageBox.warning(self, "Error", "El nombre 'eliminar' no está permitido.")
        elif nombre.lower() == "fin":
            self.terminar_registro()
        elif nombre in self.salida:
            QMessageBox.warning(self, "Error", f"El nombre '{nombre}' ya está en la lista.")
        else:
            self.salida[nombre] = True
            QMessageBox.information(self, "Registro", f"Se ha registrado a {nombre} en la lista.")
            self.nombre_input.setText("")

    def eliminar_participante(self):
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "No hay participantes para eliminar.")
        else:
            eliminado, ok = QInputDialog.getItem(self, "Eliminar participante", "Seleccione el participante a eliminar:", self.salida.keys(), 0, False)
            if ok:
                del self.salida[eliminado]
                QMessageBox.information(self, "Registro", f"Se ha eliminado a {eliminado} de la lista.")

    def terminar_registro(self):
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "Debe haber al menos un participante registrado.")
        else:
            self.close()
            self.reconocimiento = reconocimiento_voz()
            self.reconocimiento.participantes = list(self.salida.keys())
            self.reconocimiento.puntos_agenda = list(self.salida.keys())
            self.reconocimiento.show()