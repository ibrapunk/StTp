from PyQt5.QtWidgets import QMainWindow,QApplication,QComboBox, QPushButton, QLabel, QTextEdit, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem, QFileDialog, QMessageBox
from pydub import AudioSegment
from pydub.silence import split_on_silence
import json
import speech_recognition as sr
from app import app
class reconocimiento_voz(QMainWindow):
    sesiones_reconocidas = {}

    def __init__(self):
        super().__init__()
        self.title = 'Audio Divider App'
        self.left = 10
        self.top = 10
        self.width = 1200
        self.height = 1200
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        self.statusBar().showMessage('Ready')
        self.setupWidgets()
        self.show()

    def setupWidgets(self):
        global ruta_grabacion_a_dividir,ruta_carpeta,ruta_grabacion_a_reconocer,resultado
        # Agregamos un botón para pasar el texto a la tabla
        button_escribir = QPushButton('Pasar a tabla', self)
        button_escribir.setGeometry(100, 500, 300, 30)
        button_escribir.clicked.connect(self.escribir_en_tabla)
        # agregamos boton para guardar estado de sesion
        button_guardar_estado = QPushButton('Guardar estado de sesiones', self)
        button_guardar_estado.setGeometry(600, 350, 300, 30)
        button_guardar_estado.clicked.connect(self.guardar_estado_sesiones)

        # Agregamos un botón para abrir el selector de archivo para la grabación a subdividir
        button = QPushButton('Abrir archivo de audio', self)
        button.setGeometry(0, 0,500,30)
        button.clicked.connect(self.dialogo_grabacion)
        # Agregamos una caja de texto para determinar la ruta del archivo de la grabación a subdividir
        ruta_grabacion_a_dividir=QTextEdit("Sin seleccionar Archivo...",parent=self)
        ruta_grabacion_a_dividir.setDisabled=True
        ruta_grabacion_a_dividir.setGeometry(0,30,500,90)
        # Agregamos un botón para abrir el selector de la carpeta
        button = QPushButton('Abrir carpeta contenedora de segmentos de grabación', self)
        button.setGeometry(0, 120,500,30)
        button.clicked.connect(self.dialogo_carpeta)
        # Agregamos una caja de texto para determinar la ruta del archivo de la grabación a subdividir
        ruta_carpeta=QTextEdit("Sin seleccionar carpeta...",parent=self)
        ruta_carpeta.setDisabled=True
        ruta_carpeta.setGeometry(0,150,500,90)
        # Agregamos un botón para abrir el selector del archivo ya cortado a ser reconocido por SpeechRecognition
        button = QPushButton('Abrir el archivo a reconocer:', self)
        button.setGeometry(0, 210,500,30)
        button.clicked.connect(self.dialogo_grabacion_reconocer)
        # Agregamos una caja de texto para determinar la ruta del archivo de la grabación a subdividir
        ruta_grabacion_a_reconocer=QTextEdit("Sin seleccionar carpeta...",parent=self)
        ruta_grabacion_a_reconocer.setDisabled=True
        ruta_grabacion_a_reconocer.setGeometry(0,240,500,90)
        # Agregamos un botón para abrir iniciar el textRecongnition con el archivo seleccionado
        button_reconocer = QPushButton('Abrir el archivo a reconocer', self)
        button_reconocer.setGeometry(0, 210, 500, 30)
        button_reconocer.clicked.connect(self.dialogo_grabacion_reconocer)
        # Agregamos un botón para iniciar la división del audio
        button_dividir = QPushButton('Iniciar división del archivo', self)
        button_dividir.setGeometry(0, 310, 500, 30)
        button_dividir.clicked.connect(self.dividir)
        # Agregamos un botón para iniciar el SpeechRecognition
        button_reconocer_texto = QPushButton('Iniciar el reconocimiento del texto', self)
        button_reconocer_texto.setGeometry(0, 340, 500, 30)
        button_reconocer_texto.clicked.connect(self.reconocer_texto)
        # Agregamos un TextEdit para iniciar el SpeechRecognition
        resultado=QTextEdit("Aún sin reconocer texto",parent=self)
        resultado.setDisabled=True
        resultado.setGeometry(0,370,500,120)
        # Agregamos una tabla para mostrar los resultados del reconocimiento de voz
        self.tabla_resultados = QTableWidget(parent=self)
        self.tabla_resultados.setGeometry(500, 0, 450, 300)
        self.tabla_resultados.setColumnCount(4)
        self.tabla_resultados.setHorizontalHeaderLabels(['Archivo', 'Punto de agenda', 'Persona', 'Texto reconocido'])

        self.setGeometry(0, 0, 1200, 1200)
        self.setWindowTitle('Selector de archivo')
        # Agregamos un combobox para ingresar el punto de agenda
        self.punto_agenda = QComboBox(parent=self)
        self.punto_agenda.setGeometry(0, 530, 250, 30)
        self.punto_agenda.setToolTip('Seleccione un punto de agenda')
        self.punto_agenda.addItem('Punto de agenda 1')
        self.punto_agenda.addItem('Punto de agenda 2')

        
        # Agregamos un combobox para ingresar la persona hablante
        self.persona = QComboBox(parent=self)
        self.persona.setGeometry(250, 530, 250, 30)
        self.persona.setToolTip('Seleccione un participante')
        self.persona.addItem('Persona 1')
        self.persona.addItem('Persona 2')

    def dividir(self):
        global ruta_grabacion_a_dividir, ruta_carpeta
        # Duración mínima de la pausa en milisegundos
        min_silence_len = 3000
        archivo_de_audio=ruta_grabacion_a_dividir.toPlainText()
        carpeta_de_segmentos=ruta_carpeta.toPlainText()
        audio_file = AudioSegment.from_wav(archivo_de_audio)

        audio_chunks = split_on_silence(
            audio_file, 
            min_silence_len=min_silence_len, 
            silence_thresh=-50
        )

        for i, chunk in enumerate(audio_chunks):
            print (f'Recorte numero {i} procesado')
            chunk.export(f'{carpeta_de_segmentos}/grabacion_{i}.wav', format='wav')
        # Actualizar el estado de la sesión
        archivo_dividido = ruta_grabacion_a_dividir.toPlainText()
        self.sesiones_reconocidas[archivo_dividido] = False

        #Lanza un message box al finalizar las divisiones del audio
        msgBox=QMessageBox()
        msgBox.setIcon(QMessageBox.Information)
        msgBox.setText(f"Se han terminado de procesar el archivo de audio, puede visualizar el resultado en la carpeta: {carpeta_de_segmentos}")
        msgBox.setWindowTitle("Fin del proceso de división")
        msgBox.setStandardButtons(QMessageBox.Ok)
        msgBox.setDefaultButton(QMessageBox.Ok)
        response = msgBox.exec_()

    def dialogo_grabacion(self):
        # Creamos el diálogo de selección de archivo
        filename, _ = QFileDialog.getOpenFileName(window,'Seleccionar archivo')
        # Si el usuario selecciona un archivo, mostramos la ruta en un label
        if filename:
            ruta_grabacion_a_dividir.setText(filename)
    def dialogo_carpeta(self):
        # Creamos el diálogo de selección de archivo
        directory= QFileDialog.getExistingDirectory(window,'Seleccionar La carpeta')
        # Si el usuario selecciona un archivo, mostramos la ruta en un label
        if directory:
            ruta_carpeta.setText(directory)

    def dialogo_grabacion_reconocer(self):
      # Creamos el diálogo de selección de archivo
        filename, _ = QFileDialog.getOpenFileName(window,'Seleccionar archivo')
        # Si el usuario selecciona un archivo, mostramos la ruta en un label
        if filename:
            ruta_grabacion_a_reconocer.setText(filename)

    def reconocer_texto(self):
        #global resultado
        import speech_recognition as sr
        r = sr.Recognizer()
        with sr.AudioFile(ruta_grabacion_a_reconocer.toPlainText()) as source:
            audio_data = r.record(source)
        text = r.recognize_google(audio_data, language='es-ES')
        resultado.setText(text)
        # Actualizar el estado de la sesión
        archivo_reconocido = ruta_grabacion_a_reconocer.toPlainText()
        self.sesiones_reconocidas[archivo_reconocido] = True

    def actualizar_tabla_resultados(self): 
        global resultados, tabla_resultados
        tabla_resultados.setRowCount(0)
        for archivo_segmentado, resultado in resultados.items():
            punto_agenda_texto = resultado['punto_agenda']
            persona_texto = resultado['persona']
            texto_reconocido = resultado['texto']
            fila = [archivo_segmentado, punto_agenda_texto, persona_texto, texto_reconocido]
            tabla_resultados.insertRow(tabla_resultados.rowCount())
            for i, valor in enumerate(fila):
                celda = QTableWidgetItem(str(valor))
                tabla_resultados.setItem(tabla_resultados.rowCount()-1, i, celda)

    def guardar_resultados(self):
        # Obtenemos los datos de la tabla
        tabla_resultados = self.findChild(QTableWidget, "tabla_resultados")
        rows = tabla_resultados.rowCount()
        cols = tabla_resultados.columnCount()
        data = []
        for row in range(rows):
            row_data = []
            for col in range(cols):
                cell = tabla_resultados.item(row, col)
                if cell is not None:
                    row_data.append(cell.text())
                else:
                    row_data.append('')
            data.append(row_data)

        # Abrimos un cuadro de diálogo para seleccionar la ubicación del archivo de salida
        file_dialog = QFileDialog()
        file_dialog.setAcceptMode(QFileDialog.AcceptSave)
        file_dialog.setDefaultSuffix('txt')
        file_dialog.setNameFilter('Archivo de texto (*.txt)')
        file_dialog.exec_()
        file_path = file_dialog.selectedFiles()[0]

        # Escribimos los datos en el archivo
        with open(file_path, 'w') as f:
            for row_data in data:
                f.write('\t'.join(row_data) + '\n')
        # Mostramos un mensaje de confirmación
        QMessageBox.information(self, 'Guardado', 'Los resultados se han guardado en {}'.format(file_path))
    def escribir_en_tabla(self):
        archivo = ruta_grabacion_a_reconocer.toPlainText()
        punto_agenda = self.punto_agenda.currentText()
        persona = self.persona.currentText()
        texto = resultado.toPlainText()

        # Agregar los datos a la tabla
        fila = self.tabla_resultados.rowCount()
        self.tabla_resultados.insertRow(fila)
        self.tabla_resultados.setItem(fila, 0, QTableWidgetItem(archivo))
        self.tabla_resultados.setItem(fila, 1, QTableWidgetItem(punto_agenda))
        self.tabla_resultados.setItem(fila, 2, QTableWidgetItem(persona))
        self.tabla_resultados.setItem(fila, 3, QTableWidgetItem(texto))
    def guardar_estado_sesiones(self):
        # Abrir un cuadro de diálogo para seleccionar la ubicación del archivo de salida
        file_dialog = QFileDialog()
        file_dialog.setAcceptMode(QFileDialog.AcceptSave)
        file_dialog.setDefaultSuffix('json')
        file_dialog.setNameFilter('Archivo JSON (*.json)')
        file_dialog.exec_()
        file_path = file_dialog.selectedFiles()[0]

        # Guardar el diccionario en el archivo JSON
        with open(file_path, 'w') as f:
            json.dump(self.sesiones_reconocidas, f)

        # Mostrar un mensaje de confirmación
        QMessageBox.information(self, 'Guardado', 'El estado de las sesiones se ha guardado en {}'.format(file_path))


if __name__ == "__main__":
    app = QApplication([])
    window = app()
    window.show()
    app.exec_()