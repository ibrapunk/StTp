from typing import Dict
from PyQt5.QtWidgets import QWidget,QInputDialog, QLabel, QPushButton, QLineEdit, QVBoxLayout, QHBoxLayout, QMessageBox
from PyQt5.QtCore import Qt
from registrar_participantes import RegistrarParticipantes

class Registro_agenda(QWidget):
    def __init__(self):
        super().__init__()

        self.salida: Dict[str, Dict[str, bool]] = {}

        self.apartado_label = QLabel("Nombre del apartado:")
        self.apartado_input = QLineEdit()
        self.subtema_label = QLabel("Nombre del subtema: ")
        self.subtema_input = QLineEdit()
        self.agregarAp_button = QPushButton("Agregar apartado")
        self.agregarSub_button = QPushButton("Agregar subtema")
        self.editarSub_button = QPushButton("Editar subtema")
        self.eliminarSub_button = QPushButton("Eliminar subtema")
        self.terminar_button = QPushButton("Terminar registro")

        self.agregarAp_button.clicked.connect(self.agregar_apartado)
        self.agregarSub_button.clicked.connect(self.agregar_subtema)
        self.editarSub_button.clicked.connect(self.editar_subtema)
        self.eliminarSub_button.clicked.connect(self.eliminar_subtema)
        self.terminar_button.clicked.connect(self.terminar_registro)

        vbox = QVBoxLayout()
        hbox1 = QHBoxLayout()
        hbox1.addWidget(self.apartado_label)
        hbox1.addWidget(self.apartado_input)
        vbox.addLayout(hbox1)
        hbox2 = QHBoxLayout()
        hbox2.addWidget(self.subtema_label)
        hbox2.addWidget(self.subtema_input)
        vbox.addLayout(hbox2)
        vbox.addWidget(self.agregarAp_button)
        vbox.addWidget(self.agregarSub_button)
        vbox.addWidget(self.editarSub_button)
        vbox.addWidget(self.eliminarSub_button)
        vbox.addWidget(self.terminar_button)

        self.setLayout(vbox)
        self.setWindowTitle("Registro de Agenda")

    def agregar_apartado(self):
        apartado = self.apartado_input.text()
        if apartado == "":
            QMessageBox.warning(self, "Error", "Debe ingresar un apartado.")
        elif apartado.lower() == "eliminar":
            QMessageBox.warning(self, "Error", "El apartado 'eliminar' no está permitido.")
        elif apartado.lower() == "fin":
            self.terminar_registro()
        elif apartado in self.salida:
            QMessageBox.warning(self, "Error", f"El apartado '{apartado}' ya está en la lista.")
        else:
            self.salida[apartado] = {}
            QMessageBox.information(self, "Registro", f"Se ha registrado a {apartado} en la agenda.")
            self.apartado_input.setText("")

    def agregar_subtema(self):
        apartado = self.apartado_input.text()
        subtema = self.subtema_input.text()
        if apartado == "":
            QMessageBox.warning(self, "Error", "Debe seleccionar un apartado.")
        elif subtema == "":
            QMessageBox.warning(self, "Error", "Debe ingresar un subtema.")
        elif subtema.lower() == "eliminar":
            QMessageBox.warning(self, "Error", "El subtema 'eliminar' no está permitido.")
        elif subtema.lower() == "fin":
            self.terminar_registro()
        elif apartado not in self.salida:
            QMessageBox.warning(self, "Error", f"No existe el apartado '{apartado}' en la lista.")
        elif subtema in self.salida[apartado]:
            QMessageBox.warning(self, "Error", f"El subtema '{subtema}' ya está en la lista.")
        else:
            self.salida[apartado][subtema] = True
            QMessageBox.information(self, "Registro", f"Se ha registrado a {subtema} en el apartado {apartado}.")
            self.subtema_input.setText("")

    def editar_subtema(self):
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "No hay apartados para editar subtemas.")
        else:
            apartado, ok = QInputDialog.getItem(self, "Editar subtema", "Seleccione el apartado: ", list(self.salida.keys()), 0, False)
            if ok:
                if len(self.salida[apartado]) == 0:
                    QMessageBox.warning(self, "Error", "No hay subtemas para editar en el apartado seleccionado.")
                else:
                    subtema_actual, ok = QInputDialog.getItem(self, "Editar subtema", "Seleccione el subtema a editar: ", list(self.salida[apartado].keys()), 0, False)
                    if ok:
                        subtema_nuevo, ok = QInputDialog.getText(self, "Editar subtema", "Ingrese el nuevo nombre del subtema:")
                        if ok and subtema_nuevo != "":
                            del self.salida[apartado][subtema_actual]
                            self.salida[apartado][subtema_nuevo] = True
                            QMessageBox.information(self, "Agenda", f"Se ha editado el subtema '{subtema_actual}' a '{subtema_nuevo}'")

    def eliminar_subtema(self):
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "No hay apartados para eliminar subtemas.")
        else:
            apartado, ok = QInputDialog.getItem(self, "Eliminar subtema", "Seleccione el apartado: ", list(self.salida.keys()), 0, False)
            if ok:
                if len(self.salida[apartado]) == 0:
                    QMessageBox.warning(self, "Error", "No hay subtemas para eliminar en el apartado seleccionado.")
                else:
                    eliminado, ok = QInputDialog.getItem(self, "Eliminar subtema", "Seleccione el subtema a eliminar: ", list(self.salida[apartado].keys()), 0, False)
                    if ok:
                        del self.salida[apartado][eliminado]
                        QMessageBox.information(self, "Agenda", f"Se ha eliminado a {eliminado} de la lista")

    def terminar_registro(self):
        if len(self.salida) == 0:
            QMessageBox.warning(self, "Error", "Debe haber al menos un subtema registrado.")
        else:
            self.close()
            self.registro_participantes = RegistrarParticipantes()
            self.registro_participantes.show()